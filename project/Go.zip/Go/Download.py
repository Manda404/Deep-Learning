import streamlit as st
import pandas as pd
from io import BytesIO

# Fonction pour convertir le DataFrame en fichier Excel
@st.cache_data
def convert_df_to_excel(df):
    # Utilisation d'un buffer pour créer le fichier Excel en mémoire
    output = BytesIO()
    writer = pd.ExcelWriter(output, engine='xlsxwriter')
    df.to_excel(writer, index=False, sheet_name='Sheet1')
    writer.close()  # Correction de l'erreur
    processed_data = output.getvalue()
    return processed_data

# Création d'un DataFrame d'exemple
data = {'Colonne1': [1, 2, 3, 4], 'Colonne2': [5, 6, 7, 8]}
my_large_df = pd.DataFrame(data)

# Conversion du DataFrame en fichier Excel
excel_data = convert_df_to_excel(my_large_df)

# Création d'un bouton de téléchargement pour le fichier Excel
st.download_button(
    label="Télécharger les données en Excel",
    data=excel_data,
    file_name="large_df.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)
