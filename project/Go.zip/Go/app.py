import os
import pandas as pd
import streamlit as st
from io import BytesIO

#################################################### Streamlit functions #############################################################

def load_file(file):
    """
    Loads a CSV or XLSX file and returns a pandas DataFrame.
    """
    try:
        if file.type == "text/csv":
            df = pd.read_csv(file)
        elif file.type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            df = pd.read_excel(file, engine='openpyxl')
        else:
            st.error("Unsupported file type. Please upload a CSV or XLSX file.")
            return None
        return df
    except Exception as e:
        st.error(f"Error loading file: {e}")
        return None

def outer_join(data1, data2, key1, key2):
    """
    Performs an outer join between two DataFrames on the specified columns.
    """
    return pd.merge(data1, data2, how='outer', left_on=key1, right_on=key2,suffixes=('', '_dup'))

def save_database(path, df):
    """
    Saves the DataFrame to an Excel file at the specified location.
    """
    try:
        df.to_excel(path, index=False, engine='openpyxl')
    except Exception as e:
        st.error(f"Error saving the database: {e}")

def get_excel_files(directory_path):
    """
    Scans the given directory for Excel files and returns a dictionary with file names (without extensions) as keys 
    and file paths as values. Returns None if no Excel files are found.

    :param directory_path: str, the path to the directory to scan
    :return: dict or None
    """
    if not os.path.isdir(directory_path):
        raise ValueError(f"The provided path '{directory_path}' is not a directory.")

    excel_files = {}
    for filename in os.listdir(directory_path):
        if filename.endswith(('.xlsx', '.xls')):
            file_path = os.path.join(directory_path, filename)
            file_name_without_extension = os.path.splitext(filename)[0]
            excel_files[file_name_without_extension] = file_path

    return excel_files if excel_files else None

def read_excel_file(file_path):
    """
    Reads an Excel file from the given file path and returns a pandas DataFrame.
    Returns None if the file is not found or cannot be read.

    :param file_path: str, the path to the Excel file
    :return: pandas.DataFrame or None
    """
    if not os.path.isfile(file_path):
        raise ValueError(f"The provided path '{file_path}' is not a file.")

    try:
        if file_path.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file_path, engine='openpyxl')
            return df
        else:
            raise ValueError("The file is not an Excel file. Please provide a path to a .xlsx or .xls file.")
    except Exception as e:
        print(f"Error reading the Excel file: {e}")
        return None

def concatenate_dataframes(old_df, new_df):
    """
    Concatenate two dataframes and return the combined dataframe.

    Parameters:
    old_df (pd.DataFrame): The existing dataframe.
    new_df (pd.DataFrame): The new dataframe to concatenate.

    Returns:
    pd.DataFrame: The concatenated dataframe.
    """
    # Concatenate the two dataframes
    combined_df = pd.concat([old_df, new_df], ignore_index=True)

    # Optionally remove duplicate rows if needed
    combined_df = combined_df.drop_duplicates().reset_index(drop=True)
    
    return combined_df

# Function to convert the DataFrame to an Excel file
@st.cache_data
def convert_df_to_excel(df):
    # Using a buffer to create the Excel file in memory
    output = BytesIO()
    writer = pd.ExcelWriter(output, engine='xlsxwriter')
    df.to_excel(writer, index=False, sheet_name='Sheet1')
    writer.close()  # Correcting the error
    processed_data = output.getvalue()
    return processed_data

# Function to delete a database
def delete_database(file_path,database_name):
    if os.path.exists(file_path):
        os.remove(file_path)
        #st.success(f"Database {file_path} has been deleted.")
        st.success(f"The database {database_name} has been successfully removed.")
    else:
        st.error(f"File on this path: {file_path} does not exist.")
######################################################################################################################################


def main():
    st.title("Database Management")

    # Define the path to the databases directory
    path_of_databases = '/Users/surelmanda/Downloads/AirGUARD/Ergo+/Databases'
    dictionary_databases = get_excel_files(path_of_databases)
    list_of_databases_names = list(dictionary_databases.keys())

    # Instructions for the user
    #st.markdown("""
    ## Instructions
    #1. **Select an Action**: Choose whether you want to create a new database or add a new table to an existing database.
    #2. **Upload a File**: If you choose to add a new table, upload a CSV or XLSX file.
    #3. **Select Primary Key**: Choose the column to use as the primary key for the new table.
    #4. **Choose Existing Database**: Select the existing database where you want to add the new table.
    #5. **Primary Key for Existing Database**: Select the primary key column for the existing database.
    #6. **Merge and Save**: The tables will be merged, and you can save the merged database.
    #""")

    # Step 1: Choose action
    st.markdown("### Step 1: Select an Action")
    options = ['Create a new database', 'Add a new table', 'Update database', 'Download Database', 'Remove Database']
    action = st.selectbox("What would you like to do?", options, index=None)

    if action == 'Add a new table':
        # Step 2: Upload a new file
        st.markdown("### Step 2: Upload a New File")
        uploaded_file = st.file_uploader("Choose a file [CSV, XLSX]", type=['csv', 'xlsx'], accept_multiple_files=False)

        if uploaded_file is not None:
            data = load_file(uploaded_file)
            
            if data is not None:
                st.markdown("### Step 3: Preview and Select Primary Key for New Table")
                st.write("**Preview of the first 5 rows of the new table:**")
                st.write(data.head())

                # Step 3: Select primary key for the new table
                columns_list_of_table = data.columns.tolist()
                pk_column_of_table = st.selectbox("Which column to use as primary key?", columns_list_of_table, index=None, key='Valid1')

                if pk_column_of_table is not None:
                    st.markdown("### Step 4: Choose Existing Database")
                    st.write("Select a database from the list below. These are the existing databases where the new table can be added.")

                    # Step 4: Select existing database
                    if dictionary_databases:
                        list_of_databases_names = list(dictionary_databases.keys())
                        database_name = st.selectbox("Which database do you want to add the new table to?", list_of_databases_names, index=None)

                        if database_name is not None:
                            file_path = dictionary_databases.get(database_name, None)
                            if file_path is not None:
                                database = read_excel_file(file_path)
                                st.markdown("### Step 5: Preview and Select Primary Key for Existing Database")
                                st.write("**Preview of the first 5 rows of the selected database:**")
                                st.write(database.head())

                                # Step 5: Select primary key for the existing database
                                columns_list_of_db = database.columns.tolist()
                                pk_column_of_db = st.selectbox("Which column to use as primary key?", columns_list_of_db, index=None, key='Valid2')

                                # Security check for matching primary keys
                                if pk_column_of_table != pk_column_of_db:
                                    st.error("Error: The primary key columns selected do not match. Please select matching columns for the primary keys.")
                                else:
                                    st.markdown("### Step 6: Merge and Save Database")
                                    st.write("**Visualization of the new database after merging:**")
                                    
                                    # Step 6: Perform outer join and display the result
                                    merged_df = outer_join(database, data, pk_column_of_table, pk_column_of_db)
                                    st.write(merged_df.head())

                                    # Save the merged data
                                    if st.button("Save Merged Database"):
                                        save_path = os.path.join(path_of_databases, f"merged_{database_name}.xlsx")
                                        save_database(save_path, merged_df)
                                        st.success(f"Merged database saved as {save_path}")
                    else:
                        st.error("No existing databases found in the specified path.")

    if action == 'Update database':
        # Step 2: Upload a new file
        st.markdown("### Step 2: Upload a New Data File")
        uploaded_file = st.file_uploader("Choose a file [CSV, XLSX]", type=['csv', 'xlsx'], accept_multiple_files=False)

        if uploaded_file is not None:
            data = load_file(uploaded_file)
            st.write("**Preview of the first 5 rows of the old table:**")
            st.write(data.head())
            
            # Step 3: Select existing database
            if dictionary_databases:
                list_of_databases_names = list(dictionary_databases.keys())
                database_name = st.selectbox("Which database do you want to update ?", list_of_databases_names, index=None)

                if database_name is not None:
                    file_path = dictionary_databases.get(database_name, None)
                    if file_path is not None:
                        database = read_excel_file(file_path)
                        st.markdown("### Step 3: Preview the Existing Database")
                        st.write("**Preview of the first 5 rows of the selected database:**")
                        st.write(database.head())

                        st.markdown("### Step 5: Update and Save Database")
                        st.write("**Visualization of the new database after updating:**")
                        
                        # Step 5: Perform concatenation  and display the result
                        merged_df = concatenate_dataframes(database, data)
                        #outer_join(database, data, pk_column_of_table, pk_column_of_db)
                        st.write(merged_df.head())

                        # Save the merged data
                        if st.button("Save Update Database"):
                            save_path = os.path.join(path_of_databases, f"updated_{database_name}.xlsx")
                            save_database(save_path, merged_df)
                            st.success(f"Update database saved as {save_path}")

    if action == 'Create a new database':
        # Step 2: Upload a new file
        st.markdown("### Step 2: Upload a New File")
        uploaded_file = st.file_uploader("Choose a file [CSV, XLSX]", type=['csv', 'xlsx'], accept_multiple_files=False)

        if uploaded_file is not None:
            data = load_file(uploaded_file)
            if data is not None:
                st.markdown("### Step 3: Preview of The New Table")
                st.write("**Preview of the first 5 rows of the new table:**")
                st.write(data.head())

                # Step 4: Rename the database
                st.markdown("### Step 4: Rename the Database")
                st.markdown("""
                ## Instructions for Naming the Database
                Please use the following naming convention for the new database:
                - Start with an uppercase letter.
                - Do not include `_Dataset` in the name.
                
                **Example Names:**
                - `Cover` (will be saved as `Cover_Dataset`)
                - `Foam` (will be saved as `Foam_Dataset`)
                """)

                database_name = st.text_input("Enter a name for the new database:")

                if st.button("Save New Database"):
                    if database_name:
                        # Validate the naming convention
                        if not (database_name[0].isupper() and '_' not in database_name):
                            st.error("The name must start with an uppercase letter and must not include '_Dataset'.")
                        else:
                            # Add '_Dataset' suffix
                            save_path = os.path.join(path_of_databases, f"{database_name}_Dataset.xlsx")
                            save_database(save_path, data)
                            st.success(f"New database saved as {save_path}")
                    else:
                        st.error("Please enter a name for the new database.")

    if action == 'Download Database':
        # Step 2: Choose a database to download
        st.markdown("### Step 2: Choose a Database to Download")
        database_name = st.selectbox("Select a database to download", list_of_databases_names, index=None)
        if database_name:
            file_path = dictionary_databases.get(database_name, None)
            if file_path is not None:
                df_database = read_excel_file(file_path)
                st.markdown("### Step 3: Preview of The Table")
                st.write("**Preview of the first 5 rows of the table:**")
                st.write(df_database.head())
                # Conversion du DataFrame en fichier Excel
                excel_data = convert_df_to_excel(df_database)
                if st.button("Download"):
                    st.download_button(
                        label="Download Database",
                        data=excel_data,
                        file_name=database_name+''+'.xlsx',
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
        else:
            st.info("No databases available for download.")
    
    if action == 'Remove Database':
        # Step 2: Choose a database to remove
        st.markdown("### Step 2: Choose a Database to Remove")
        database_name = st.selectbox("Select a database to download", list_of_databases_names, index=None)
        if database_name:
            file_path = dictionary_databases.get(database_name, None)
            if file_path is not None:
                df_database = read_excel_file(file_path)
                st.markdown("### Step 3: Preview of The Table")
                st.write("**Preview of the first 5 rows of the table:**")
                st.write(df_database.head())
                st.markdown("### Step 4: Delete a Database")
                if st.button("Confirm Removal"):
                    delete_database(file_path,database_name)
                    #st.success(f"The database {database_name} has been successfully removed.")
        else:
            st.info("No databases available to remove.")
if __name__ == "__main__":
    main()
